"use client"

import { useRef } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, useGLTF, Environment, Float } from "@react-three/drei"
import { Button } from "@/components/ui/button"
import { Shield, Download } from "lucide-react"
import type * as THREE from "three"

function CyberShield(props: any) {
  const { nodes, materials } = useGLTF("/assets/3d/duck.glb") as any
  const ref = useRef<THREE.Mesh>(null!)

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.getElapsedTime() * 0.3
    }
  })

  return (
    <Float speed={1.5} rotationIntensity={0.5} floatIntensity={0.5}>
      <mesh
        {...props}
        ref={ref}
        geometry={nodes.LOD3spShape.geometry}
        material={materials.blinn3SG}
        rotation={[0.5, 0, 0]}
        scale={2}
      />
    </Float>
  )
}

const Hero = () => {
  return (
    <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 z-0">
        <Canvas camera={{ position: [0, 0, 8], fov: 45 }}>
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1} />
          <CyberShield position={[0, 0, 0]} />
          <Environment preset="city" />
          <OrbitControls enableZoom={false} enablePan={false} />
        </Canvas>
      </div>

      <div className="container relative z-10 mx-auto px-4 text-center">
        <div className="backdrop-blur-sm bg-background/30 p-8 rounded-xl max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-primary to-purple-500 text-transparent bg-clip-text">
            Annie Jaison J S
          </h1>
          <h2 className="text-xl md:text-2xl font-medium mb-6 text-foreground/90">
            Cybersecurity Enthusiast & Developer
          </h2>
          <p className="text-lg mb-8 text-foreground/80 max-w-2xl mx-auto">
            Dedicated student passionate about cybersecurity, ethical hacking, and software development. Building secure
            digital solutions and exploring the latest in tech.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="gap-2">
              <Shield className="h-5 w-5" />
              View Projects
            </Button>
            <Button size="lg" variant="outline" className="gap-2">
              <Download className="h-5 w-5" />
              Download Resume
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <a href="#about" className="text-foreground/60 hover:text-primary">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M12 5v14M5 12l7 7 7-7" />
          </svg>
        </a>
      </div>
    </section>
  )
}

export default Hero

