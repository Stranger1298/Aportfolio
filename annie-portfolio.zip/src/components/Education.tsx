"use client"

import { motion } from "framer-motion"
import { Calendar, Award, BookOpen } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const Education = () => {
  const education = [
    {
      institution: "Sapthagiri College of Engineering",
      degree: "Bachelor of Engineering in Computer Science and Engineering",
      period: "2022 - 2026",
      gpa: "8.5",
      icon: <BookOpen className="h-10 w-10 text-primary" />,
    },
  ]

  const certifications = [
    {
      name: "Google Cybersecurity Professional Certificate",
      issuer: "Google",
      icon: <Award className="h-10 w-10 text-primary" />,
    },
    {
      name: "Python (Basic)",
      issuer: "HackerRank",
      icon: <Award className="h-10 w-10 text-primary" />,
    },
    {
      name: "Java (Basic)",
      issuer: "HackerRank",
      icon: <Award className="h-10 w-10 text-primary" />,
    },
  ]

  return (
    <section id="education" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-bold mb-4">Education & Certifications</h2>
          <div className="h-1 w-20 bg-primary mx-auto mb-8"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-xl font-bold mb-6 flex items-center">
              <BookOpen className="h-5 w-5 mr-2" />
              Education
            </h3>

            {education.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="mb-6 border-none bg-background/50 backdrop-blur-sm hover:shadow-md transition-shadow">
                  <CardHeader className="flex flex-row items-start space-x-4 pb-2">
                    <div className="mt-1">{item.icon}</div>
                    <div>
                      <CardTitle>{item.institution}</CardTitle>
                      <CardDescription className="text-foreground/70">{item.degree}</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-muted-foreground mb-2">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span>{item.period}</span>
                    </div>
                    <div className="flex items-center text-sm font-medium">
                      <span>GPA: {item.gpa}</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 flex items-center">
              <Award className="h-5 w-5 mr-2" />
              Certifications
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {certifications.map((cert, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full border-none bg-background/50 backdrop-blur-sm hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="mx-auto mb-4">{cert.icon}</div>
                      <CardTitle className="text-center">{cert.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-center text-foreground/70">
                        Issued by {cert.issuer}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Education

