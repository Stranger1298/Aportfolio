"use client"

import { useRef } from "react"
import { motion } from "framer-motion"
import { Canvas, useFrame } from "@react-three/fiber"
import { Text, Float } from "@react-three/drei"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type * as THREE from "three"

const SkillSphere = ({ skills }: { skills: string[] }) => {
  const groupRef = useRef<THREE.Group>(null!)

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.getElapsedTime() * 0.05
    }
  })

  return (
    <group ref={groupRef}>
      {skills.map((skill, i) => {
        const phi = Math.acos(-1 + (2 * i) / skills.length)
        const theta = Math.sqrt(skills.length * Math.PI) * phi
        const radius = 3

        const x = radius * Math.cos(theta) * Math.sin(phi)
        const y = radius * Math.sin(theta) * Math.sin(phi)
        const z = radius * Math.cos(phi)

        return (
          <Float key={i} speed={1} rotationIntensity={0.5} floatIntensity={0.5}>
            <Text
              position={[x, y, z]}
              fontSize={0.3}
              color="#ffffff"
              anchorX="center"
              anchorY="middle"
              font="/fonts/Inter_Bold.json"
            >
              {skill}
            </Text>
          </Float>
        )
      })}
    </group>
  )
}

const Skills = () => {
  const technicalSkills = [
    { name: "Cybersecurity", level: 85 },
    { name: "Python", level: 80 },
    { name: "Java", level: 75 },
    { name: "C", level: 70 },
    { name: "SQL", level: 65 },
    { name: "Machine Learning Basics", level: 60 },
  ]

  const softSkills = [
    { name: "Communication", level: 90 },
    { name: "Problem Solving", level: 85 },
    { name: "Teamwork", level: 80 },
    { name: "Adaptability", level: 85 },
    { name: "Time Management", level: 75 },
  ]

  const sphereSkills = [
    "Cybersecurity",
    "Python",
    "Java",
    "C",
    "SQL",
    "Machine Learning",
    "Ethical Hacking",
    "Web Dev",
    "Data Analysis",
    "Networking",
    "Linux",
    "Git",
  ]

  return (
    <section id="skills" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-bold mb-4">Skills</h2>
          <div className="h-1 w-20 bg-primary mx-auto mb-8"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <div className="mb-12">
              <h3 className="text-xl font-bold mb-6">Technical Skills</h3>
              <div className="space-y-6">
                {technicalSkills.map((skill, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{skill.name}</span>
                      <span>{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </motion.div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-6">Soft Skills</h3>
              <div className="space-y-6">
                {softSkills.map((skill, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{skill.name}</span>
                      <span>{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          <motion.div
            className="order-1 lg:order-2 h-[400px] lg:h-[500px]"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <Card className="h-full border-none bg-background/50 backdrop-blur-sm">
              <CardContent className="p-0 h-full">
                <Canvas camera={{ position: [0, 0, 6], fov: 45 }}>
                  <ambientLight intensity={0.5} />
                  <pointLight position={[10, 10, 10]} intensity={1} />
                  <SkillSphere skills={sphereSkills} />
                </Canvas>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

export default Skills

