"use client"

import { motion } from "framer-motion"
import { Shield, Code, Server, Lock } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const About = () => {
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-bold mb-4">About Me</h2>
          <div className="h-1 w-20 bg-primary mx-auto mb-8"></div>
          <p className="max-w-3xl mx-auto text-lg text-foreground/80">
            I'm a Computer Science and Engineering student at Sapthagiri College of Engineering with a passion for
            cybersecurity and ethical hacking. I've completed multiple internships in the cybersecurity field and am
            constantly expanding my knowledge through hands-on projects and research.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              icon: <Shield className="h-10 w-10 text-primary" />,
              title: "Cybersecurity",
              description: "Passionate about protecting digital assets and identifying vulnerabilities",
            },
            {
              icon: <Code className="h-10 w-10 text-primary" />,
              title: "Development",
              description: "Experienced in C, Java, Python, SQL, and web technologies",
            },
            {
              icon: <Server className="h-10 w-10 text-primary" />,
              title: "Systems",
              description: "Knowledge of network security and system administration",
            },
            {
              icon: <Lock className="h-10 w-10 text-primary" />,
              title: "Ethical Hacking",
              description: "Trained in identifying and addressing security vulnerabilities",
            },
          ].map((item, index) => (
            <motion.div
              key={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: {
                  opacity: 1,
                  y: 0,
                  transition: {
                    duration: 0.6,
                    delay: index * 0.1,
                  },
                },
              }}
            >
              <Card className="h-full border-none bg-background/50 backdrop-blur-sm hover:bg-background/80 transition-all">
                <CardHeader className="text-center pb-2">
                  <div className="mx-auto mb-4">{item.icon}</div>
                  <CardTitle>{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-foreground/70">{item.description}</CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default About

