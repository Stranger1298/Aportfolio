"use client"

import { motion } from "framer-motion"
import { Calendar, MapPin } from "lucide-react"

const Experience = () => {
  const experiences = [
    {
      company: "ShadowFox",
      position: "Intern",
      period: "May 2024 - June 2024",
      description: "Internship in Cyber Security, focusing on security assessments and vulnerability analysis.",
      location: "Bangalore, India",
    },
    {
      company: "Prodigy Infotech",
      position: "Intern",
      period: "April 2024 - May 2024",
      description: "Internship in Cyber Security, working on security protocols and threat detection.",
      location: "Bangalore, India",
    },
    {
      company: "CFSS Cyber & Forensics Security Solutions",
      position: "Intern",
      period: "March 2024 - April 2024",
      description:
        "Internship in Cyber Security and Ethical Hacking, learning about digital forensics and security solutions.",
      location: "Bangalore, India",
    },
  ]

  return (
    <section id="experience" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-bold mb-4">Work Experience</h2>
          <div className="h-1 w-20 bg-primary mx-auto mb-8"></div>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          <div className="relative border-l-2 border-primary/30 pl-8 ml-4">
            {experiences.map((exp, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="mb-12 relative"
              >
                <div className="absolute -left-12 top-0 w-6 h-6 rounded-full bg-primary border-4 border-background"></div>
                <div className="bg-card rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
                  <h3 className="text-xl font-bold text-foreground">{exp.company}</h3>
                  <h4 className="text-lg font-medium text-primary mb-2">{exp.position}</h4>
                  <div className="flex items-center text-sm text-muted-foreground mb-4">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{exp.period}</span>
                    <MapPin className="h-4 w-4 ml-4 mr-2" />
                    <span>{exp.location}</span>
                  </div>
                  <p className="text-foreground/80">{exp.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default Experience

