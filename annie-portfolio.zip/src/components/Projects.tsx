"use client"
import { motion } from "framer-motion"
import { ExternalLink, Github } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const Projects = () => {
  const projects = [
    {
      title: "Drug Interaction Checker",
      description:
        "A web application that checks for potential interactions between medications. Built with JavaScript and MongoDB, using Axios for API calls, Mongoose for MongoDB object modeling, and CORS for cross-origin resource sharing.",
      tags: ["JavaScript", "MongoDB", "Axios", "Mongoose", "CORS"],
      image: "/placeholder.svg?height=200&width=400",
      links: {
        demo: "#",
        github: "#",
      },
    },
    {
      title: "Chatbot without AI",
      description:
        "A rule-based chatbot application built with Java and Spring Boot that provides automated responses based on predefined patterns and rules.",
      tags: ["Java", "Spring Boot", "REST API"],
      image: "/placeholder.svg?height=200&width=400",
      links: {
        demo: "#",
        github: "#",
      },
    },
    {
      title: "Restaurant Management System",
      description:
        "A Python application with a graphical user interface built using tkinter and SQLite databases for managing restaurant operations.",
      tags: ["Python", "tkinter", "SQLite"],
      image: "/placeholder.svg?height=200&width=400",
      links: {
        demo: "#",
        github: "#",
      },
    },
    {
      title: "Phone Number Book",
      description:
        "A C application with core features including adding numbers, displaying numbers, deleting numbers, searching numbers, and updating numbers.",
      tags: ["C", "Data Structures"],
      image: "/placeholder.svg?height=200&width=400",
      links: {
        demo: "#",
        github: "#",
      },
    },
    {
      title: "Alarm Clock",
      description: "A Python application using Beepy for audio and datetime for accurate alarm functionality.",
      tags: ["Python", "Beepy", "datetime"],
      image: "/placeholder.svg?height=200&width=400",
      links: {
        demo: "#",
        github: "#",
      },
    },
  ]

  return (
    <section id="projects" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-bold mb-4">Projects</h2>
          <div className="h-1 w-20 bg-primary mx-auto mb-8"></div>
          <p className="max-w-3xl mx-auto text-lg text-foreground/80">
            Here are some of the projects I've worked on, showcasing my skills in various programming languages and
            technologies.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full overflow-hidden border-none bg-background/50 backdrop-blur-sm hover:shadow-lg transition-all">
                <div className="overflow-hidden">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-48 object-cover transition-transform hover:scale-105 duration-300"
                  />
                </div>
                <CardHeader>
                  <CardTitle>{project.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-foreground/70 mb-4">{project.description}</CardDescription>
                  <div className="flex flex-wrap gap-2 mt-4">
                    {project.tags.map((tag, i) => (
                      <Badge key={i} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" size="sm" className="gap-2">
                    <Github className="h-4 w-4" />
                    Code
                  </Button>
                  <Button size="sm" className="gap-2">
                    <ExternalLink className="h-4 w-4" />
                    Demo
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Projects

